# 07th-mod website developer readme

For the original versions of each image, see the "image_originals" folder. For the "orginals" which are `.jpg` files, I'm not sure where the completely uncompressed versions of these images are.
